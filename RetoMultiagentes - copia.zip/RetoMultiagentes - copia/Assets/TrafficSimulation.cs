using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TrafficSimulation : MonoBehaviour
{
    public GameObject vehiclePrefab; 
    public List<GameObject> trafficLights = new List<GameObject>();
    private TrafficSimulationData simulationData;
    private Dictionary<int, GameObject> vehicles = new Dictionary<int, GameObject>();
    private int currentStep = 0;

    void Start()
    {
        LoadJsonFromFile("simulation_data");
        StartCoroutine(SimulationCoroutine());
    }

    void LoadJsonFromFile(string fileName)
    {
        TextAsset file = (TextAsset)Resources.Load((fileName), typeof(TextAsset));
        Debug.Log(file.text);
        if (file != null)
        {
            simulationData = JsonUtility.FromJson<TrafficSimulationData>(file.text);
            Debug.Log("Datos de simulación cargados correctamente.");
        }
        else
        {
            Debug.LogError("No se pudo cargar el archivo JSON.");
        }
    }

    IEnumerator SimulationCoroutine()
    {
        while (currentStep < simulationData.steps.Count)
        {
            SimulationStep step = simulationData.steps[currentStep];
            UpdateTrafficLights(step.traffic_lights);
            UpdateVehicles(step.vehicles);

            yield return new WaitForSeconds(1); // Espera un segundo antes de proceder al siguiente paso
            currentStep++;
        }
    }

    void UpdateTrafficLights(List<TrafficLightData> trafficLightsData)
    {
        foreach (TrafficLightData lightData in trafficLightsData)
        {
            // Intenta encontrar un GameObject de semáforo existente por su ID
            Light lightComponent = FindLightById(lightData.id);

            // Si no se encuentra, crea uno nuevo
            if (lightComponent == null)
            {
                GameObject lightGameObject = new GameObject("TrafficLight_" + lightData.id);
                lightComponent = lightGameObject.AddComponent<Light>();
                lightComponent.type = LightType.Point; // o el tipo que mejor se adapte
                lightComponent.range = 100; // Ajusta según la necesidad de tu escena
                trafficLights.Add(lightGameObject);
            }

            // Establece la posición de la luz
            lightComponent.transform.position = new Vector3(lightData.x * 27, 10, lightData.y * 27);

            // Actualiza el color de la luz según el estado del semáforo
            switch (lightData.state)
            {
                case "green":
                    lightComponent.color = Color.green;
                    break;
                case "yellow":
                    lightComponent.color = Color.yellow;
                    break;
                case "red":
                    lightComponent.color = Color.red;
                    break;
                default:
                    Debug.LogError("Estado de semáforo desconocido: " + lightData.state);
                    break;
            }
        }
    }

    // Método auxiliar para buscar una luz por ID
    Light FindLightById(string id)
    {
        foreach (GameObject lightObj in trafficLights) // Asumiendo que tienes una lista llamada trafficLights
        {
            if (lightObj.name == "TrafficLight_" + id)
            {
                return lightObj.GetComponent<Light>();
            }
        }
        return null; // No se encontró
    }

    void UpdateVehicles(List<VehicleData> vehiclesData)
    {
        foreach (VehicleData vehicleData in vehiclesData)
        {
            Debug.Log("Vehicle " + vehicleData.direction);
            if (!vehicles.ContainsKey(vehicleData.id))
            {
                GameObject vehicle = Instantiate(vehiclePrefab, new Vector3(vehicleData.x * 27, 8, vehicleData.y * 27), Quaternion.identity);
                Vector3 direction = new Vector3(vehicleData.direction[0], 0, vehicleData.direction[1]);
                vehicle.transform.rotation = Quaternion.Euler(0, CalculateRotationY(direction), 0);
                vehicles.Add(vehicleData.id, vehicle);
            }
            else
            {
                GameObject vehicle = vehicles[vehicleData.id];
                Vector3 newPosition = new Vector3(vehicleData.x * 27, 8, vehicleData.y * 27);
                Vector3 direction = new Vector3(vehicleData.direction[0], 0, vehicleData.direction[1]);
                vehicle.transform.rotation = Quaternion.Euler(0, CalculateRotationY(direction), 0);
                float moveSpeed = 27f; 
                StartCoroutine(MoveVehicleToPosition(vehicle, newPosition, moveSpeed, direction));
            }
        }
    }

    int CalculateRotationY(Vector3 dir){
        if(dir.x == 1 && dir.z == 0){
            return 0;
        }
        else if(dir.x == -1 && dir.z == 0){
            return 180;
        }
        else if(dir.x == 0 && dir.z == 1){
            return 90;
        }
        else if(dir.x == 0 && dir.z == -1){
            return 90;
        }
        else{
            return 0;
        }
    }

    IEnumerator MoveVehicleToPosition(GameObject vehicle, Vector3 newPosition, float moveSpeed, Vector3 newDirection)
    {
        while (Vector3.Distance(vehicle.transform.position, newPosition) > 0.05f)
        {
            vehicle.transform.position = Vector3.MoveTowards(vehicle.transform.position, newPosition, moveSpeed * Time.deltaTime);
            yield return null;
        }
    }

    [System.Serializable]
    public class TrafficSimulationData
    {
        public List<SimulationStep> steps;
    }

    [System.Serializable]
    public class SimulationStep
    {
        public List<TrafficLightData> traffic_lights;
        public List<VehicleData> vehicles;
    }

    [System.Serializable]
    public class TrafficLightData
    {
        public string id;
        public string state;
        public float x;
        public float y;
    }

    [System.Serializable]
    public class VehicleData
    {
        public int id;
        public float x;
        public float y;
        public float[] direction;
    }
}
